#include <pspkernel.h>
#include <pspdebug.h>
#include <pspctrl.h>
#include <stdio.h>
#include <string.h>

PSP_MODULE_INFO("PS2_Portable", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);

static int controller_mode = 0;
static int selected = 0;
static const char *items[] = {
    "Browse PS2 ISO (prototype)",
    "Controller mode",
    "About",
    "Exit"
};
static const char *modes[] = {"Dual Analog", "Single Analog", "Custom"};

static void draw_screen(void) {
    int i;
    pspDebugScreenSetXY(0, 0);
    pspDebugScreenPrintf("========================================\n");
    pspDebugScreenPrintf("             PS2 PORTABLE               \n");
    pspDebugScreenPrintf("========================================\n\n");
    pspDebugScreenPrintf("  Prototype menu - not a PS2 emulator\n\n");
    for (i = 0; i < 4; ++i) {
        pspDebugScreenPrintf("%s %s\n", i == selected ? ">" : " ", items[i]);
        if (i == 1)
            pspDebugScreenPrintf("    Current: %s\n", modes[controller_mode]);
    }
    pspDebugScreenPrintf("\nControls: D-pad Up/Down, X = Select, O = Back\n");
    pspDebugScreenPrintf("\n");
}

int main(void) {
    SceCtrlData pad;
    int running = 1;

    pspDebugScreenInit();
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);

    while (running) {
        sceCtrlReadBufferPositive(&pad, 1);

        if (pad.Buttons & PSP_CTRL_UP) {
            selected = (selected + 3) % 4;
            sceKernelDelayThread(160000);
        } else if (pad.Buttons & PSP_CTRL_DOWN) {
            selected = (selected + 1) % 4;
            sceKernelDelayThread(160000);
        }

        if (pad.Buttons & PSP_CTRL_CROSS) {
            if (selected == 0) {
                pspDebugScreenClear();
                pspDebugScreenSetXY(0, 0);
                pspDebugScreenPrintf("ISO browser is not implemented yet.\n");
                pspDebugScreenPrintf("This menu item is a placeholder.\n\n");
                pspDebugScreenPrintf("Press O to return.\n");
                while (1) {
                    sceCtrlReadBufferPositive(&pad, 1);
                    if (pad.Buttons & PSP_CTRL_CIRCLE) break;
                    sceKernelDelayThread(50000);
                }
            } else if (selected == 1) {
                controller_mode = (controller_mode + 1) % 3;
            } else if (selected == 2) {
                pspDebugScreenClear();
                pspDebugScreenSetXY(0, 0);
                pspDebugScreenPrintf("PS2_Portable prototype\n\n");
                pspDebugScreenPrintf("This is a PSP homebrew menu only.\n");
                pspDebugScreenPrintf("It does not load or run PS2 ISOs.\n");
                pspDebugScreenPrintf("Real PS2 emulation on PSP hardware\n");
                pspDebugScreenPrintf("is not practically feasible.\n\n");
                pspDebugScreenPrintf("Press O to return.\n");
                while (1) {
                    sceCtrlReadBufferPositive(&pad, 1);
                    if (pad.Buttons & PSP_CTRL_CIRCLE) break;
                    sceKernelDelayThread(50000);
                }
            } else if (selected == 3) {
                running = 0;
            }
            sceKernelDelayThread(180000);
        }

        pspDebugScreenClear();
        draw_screen();
        sceKernelDelayThread(30000);
    }

    sceKernelExitGame();
    return 0;
}
