# PS2_Portable

A starter PSP homebrew menu project intended to build as `EBOOT.PBP` for PPSSPP or a compatible PSP homebrew environment.

## Important status

This repository is a **menu prototype**, not a PlayStation 2 emulator. The ISO browser is currently a placeholder, and the controller modes currently change a displayed setting only. No PS2 ISO is loaded or executed.

A PSP does not have the CPU/GPU resources needed for practical full PS2 emulation. A menu or an ISO file wrapper cannot overcome that hardware limitation.

## Build

The included GitHub Actions workflow attempts to install PSPSDK and build `EBOOT.PBP` when you push to `main`, or when you manually run the workflow.

1. Upload these project files to a GitHub repository named `PS2_Portable`.
2. Open the repository's **Actions** tab.
3. Select **Build PSP homebrew**.
4. Choose **Run workflow** if it has not started automatically.
5. When it completes, open the run and download the `PS2_Portable-EBOOT` artifact.

## Run in PPSSPP

Extract the downloaded artifact and place `EBOOT.PBP` in:

`PSP/GAME/PS2_Portable/EBOOT.PBP`

Then open PPSSPP and launch it from the Games list.

## Controls

- D-pad Up/Down: move through the menu
- X: select / cycle controller mode
- O: return from information screens

## Planned work

- Implement a real PSP Memory Stick file browser.
- Add actual controller remapping.
- Keep PSP-specific features separate from any future Android companion application.
